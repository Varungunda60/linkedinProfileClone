package com.example.LinkedinBasicProfle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LinkedinBasicProfleApplicationTests {

	@Test
	void contextLoads() {
	}

}
