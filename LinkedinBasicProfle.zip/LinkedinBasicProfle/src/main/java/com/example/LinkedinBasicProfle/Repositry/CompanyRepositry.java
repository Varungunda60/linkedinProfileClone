package com.example.LinkedinBasicProfle.Repositry;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.LinkedinBasicProfle.entity.Company;


public interface CompanyRepositry extends JpaRepository<Company, Long> {

}



