package com.example.LinkedinBasicProfle.Repositry;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.LinkedinBasicProfle.entity.Skills;


public interface SkillsRepositry extends JpaRepository<Skills,Long>{

}
