package com.example.LinkedinBasicProfle.Repositry;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.LinkedinBasicProfle.entity.Experience;

public interface ExperienceRepositry extends JpaRepository<Experience,Long>{

}
